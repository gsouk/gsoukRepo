﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class frmCalculator : Form
    {
        public frmCalculator()
        {
            InitializeComponent();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            //// Show the dialog and get result.
            //DialogResult result = openFileDialog1.ShowDialog();
            //if (result == DialogResult.OK) // Test result.
            //{
            //}
            //Console.WriteLine(result); // <-- For debugging use.

            string[] lineOfContents = File.ReadAllLines(@"C:\Work\CSharpSamples\Calculator\Calculator.txt");

            cboInstruction.Items.Clear();
            foreach (var line in lineOfContents)
            {
                cboInstruction.Items.Add(line);
            }

            lblCalculated.Text = "  ";
            lblErrMsg.Text = "";
        }
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int CalculatedResults = 0;

            if (cboInstruction.SelectedIndex == -1)
            {
                lblCalculated.Text = "  ";
                lblErrMsg.Text = "Must select an Instruction in the Dropdown above.";
                return;
            }

            CalculatedResults = (CalculateIt(cboInstruction.Text));

            if (CalculatedResults == -1)
            {
                lblCalculated.Text = "  ";
                lblErrMsg.Text = "Invalid Instructions string format, please check the Inout file and try again.";
                return;
            }
            else
            {
                lblErrMsg.Text = "";
                lblCalculated.Text = CalculatedResults.ToString();
            }
        }

        public static int ResultZ()
        {
            int Res = 0;
            return Res;

        }
        public static int CalculateIt(string strInstruction)
        {
            int Sum = 0;
            string Operator = "";
            int ThisDig = 0;
            int LastDig = 0;

            // First extract the last digit of the Instruction
            string lastchar = strInstruction.Split(' ').Last();

            int i;
            if (!int.TryParse(lastchar, out i))
            {
                return -1;
            }
            else
            {
                LastDig = int.Parse(lastchar);
            }

            string[] Commands = strInstruction.Split(',');

            int inc = 0;
            foreach (var OperatorDigit in Commands)
            {
                // Split Operator and the Digit
                string[] OprDig = OperatorDigit.Trim().Split(' ');

                // Save Operator and convert to upper case
                Operator = OprDig[0].ToUpper();

                // Validate calculator Operators
                if ((Operator != "ADD") && (Operator != "SUBTRACT") && (Operator != "MULTIPLY") && (Operator != "DIVIDE") && (Operator != "APPLY"))
                {
                    return -1;
                }

                // If the Didgit following the Operator is Not numeric then return error
                int j;
                if (!int.TryParse(OprDig[1], out j))
                {
                    return -1;
                }
                else
                {
                    ThisDig = int.Parse(OprDig[1]);
                }

                switch (Operator)
                {
                    case "ADD":
                        if (inc == 0)
                        {
                            Sum = ThisDig + LastDig;
                        }
                        else
                        {
                            Sum = Sum + ThisDig;
                        }
                        inc++;
                        break;
                    case "SUBTRACT":
                        if (inc == 0)
                        {
                            Sum = ThisDig - LastDig;
                        }
                        else
                        {
                            Sum = Sum - ThisDig;
                        }
                        inc++;
                        break;
                    case "MULTIPLY":
                        if (inc == 0)
                        {
                            Sum = ThisDig * LastDig;
                        }
                        else
                        {
                            Sum = Sum * ThisDig;
                        }
                        inc++;
                        break;
                    case "DIVIDE":


                        if (inc == 0)
                        {
                            Sum = ThisDig / LastDig;
                        }
                        else
                        {
                            Sum = Sum / ThisDig;
                        }
                        inc++;
                        break;
                }

            }

            return Sum;
        }
    }
}
