﻿
using ClassLibraryCSharpTest.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Parser class created with the intention of wrapping the Tokenizer
    /// but that logic currently sits in the calculator
    /// </summary>
    public class Parser
    {
        ITokenizer tokenizer;
        public Parser(ITokenizer tokenizer)
        {
            this.tokenizer = tokenizer;

        }
        public INode ParseNode()
        {
            return null;

        }
    }
}
