﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ClassLibraryCSharpTest.Common
{
    public class SyntaxValidator
    {
        /// <summary>
        /// Class for validation that will check the format of a string before
        /// we start to parse it. it looks for (word) (space) (decimal or int)
        /// </summary>
        /// <param name="instruction"></param>
        /// <returns></returns>
        public bool IsValid(string instruction)
        {
            Regex validator = new Regex(@"^\w+?\s-?\d+(?:\.\d+)??$");


            return validator.IsMatch(instruction);

        }
    }
}
