﻿using System;
using ClassLibraryCSharpTest.Common;
using Microsoft.Extensions.Logging;

namespace ClassLibraryCSharpTest
{
    public class Calculator
    {

        private ITokenizer tokenizer;
        private ILogger<Calculator> logger;
        private SyntaxValidator syntaxvalidator;

        public Calculator(ILogger<Calculator> logger, ITokenizer tokenizer)
        {
            this.logger = logger;
            this.tokenizer = tokenizer;
            this.syntaxvalidator = new SyntaxValidator();
        }
        public double Process(IScript script)
        {

            Node TempNode = null;
            ExpressionTree tree = new ExpressionTree();

            foreach (string line in script.GetLines())
            {
                var currentline = tokenizer.ReduceWhitespace(line);

                if (!syntaxvalidator.IsValid(currentline))
                {
                    throw new SyntaxException(String.Format($" The line '{0}' is invalid", line));
                    Console.WriteLine("The format of line is invalid" + line);
                }


                TempNode = tokenizer.Parse(currentline);



                if (TempNode.IsApplyOperation())
                {
                    tree.HandleApply(TempNode);
                    break;
                }


                tree.HandleNode(TempNode);

            }


            return tree.Evalute();




        }
    }
}
