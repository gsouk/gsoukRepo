﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Interface used by the Node to define the Evaluate function.
    /// This is used both by the Constant and Binaty nodes
    /// </summary>
    public interface INode
    {
        double Evaluate();
    }
}
