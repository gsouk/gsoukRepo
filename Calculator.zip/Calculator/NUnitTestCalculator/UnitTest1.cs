using NUnit.Framework;

namespace NUnitTestCalculator
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("add 2, multiply 2, apply 3"), 10);
        }
    }
}