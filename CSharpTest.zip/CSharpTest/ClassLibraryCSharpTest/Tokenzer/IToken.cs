﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Interface used as a base for our tokens
    /// </summary>
    public interface IToken
    {
    }
}
