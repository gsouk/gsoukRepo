﻿using ClassLibraryCSharpTest.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest
{
    /// <summary>
    /// Initially the tree was just a node but we've wrapped this class
    /// so we can track the current node as when we create a new node the
    /// previous node becomes a child of it
    /// </summary>
    public class ExpressionTree
    {
        Node RootNode = null;
        Node CurrentNode = null;


        public void HandleApply(Node TempNode)
        {
            using (var applynode = TempNode as OperationNode)
            {
                if (applynode != null && applynode.Operator.Operator == Operators.apply)
                {
                    using (var constantnode = applynode.RightNode as NodeConstant)
                        if (constantnode != null)
                        {
                            RootNode.SetApply(constantnode.Value);

                        }
                   
                }

            }

         
        }

        public void HandleNode(Node TempNode)
        {
            if (CurrentNode != null)
            {
                TempNode.LeftNode = CurrentNode;
                CurrentNode = TempNode;

            }
            else
            {
                CurrentNode = TempNode;
            }

            RootNode = CurrentNode;
        }


        public double Evalute()
        {
            return RootNode.Evaluate();
        }
      
    }
}
