﻿using System;

/// <summary>
/// Contains Enumerables, OperatorToke class and Operators property
/// </summary>
namespace ClassLibraryCSharpTest.Common
{

    

   
    public enum Operators
    {
        add,
        subtract,
        divide,
        multiply,
        apply
    }

    public class OperatorToken : IToken
    {
        public Func<double, double, double> BinaryOperation { get; set; }

        private Operators _operator;
        public OperatorToken(string tokenString)
        {
            //  Enum.TryParse(tokenString, out this._operator);

            try
            {
             this._operator=(Operators)Enum.Parse(typeof(Operators), tokenString.ToLower());
            }
            catch
            {
                throw new UnknownOperatorException(String.Format("could not find the operator {0}", tokenString));
            }

            switch (this._operator)
            {
                case Operators.add:
                    BinaryOperation = (l, r) => l + r;
                    break;
                case Operators.multiply:
                    BinaryOperation = (l, r) => l * r;
                    break;
                case Operators.divide:
                    BinaryOperation = (l, r) => l / r;
                    break;
                case Operators.subtract:
                    BinaryOperation = (l, r) => l - r;
                    break;
                case Operators.apply:
                    BinaryOperation = (l, r) => r;
                    break;

            }
        }

        public Operators Operator
        {
            get
            {
                return _operator;
            }

        }
    }

}