﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// This is the Implemention shared by both the Constant and Operator node
    /// </summary>
    public abstract class Node:INode,IDisposable
    {
        public Node LeftNode { get; set; }
        public Node RightNode { get; set; }

        public void Dispose()
        {
          
        }

        public virtual double Evaluate()
        {
            throw new Exception("cannot evaluate");
        }

        public void SetApply(double value)
        {
            if(LeftNode!=null)
            {
                LeftNode.SetApply(value);
            }
            else
            {
                LeftNode = new NodeConstant(value);
            }
        }
    }
}
