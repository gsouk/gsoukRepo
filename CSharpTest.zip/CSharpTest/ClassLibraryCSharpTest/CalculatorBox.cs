﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Simple Box class around the Calculator which will try to satisfy the dependencies of the class
    /// </summary>
    public class CalculatorBox
    {
        IServiceProvider serviceProvider;

        public CalculatorBox()
        {
             serviceProvider = Configure();
        }

        public Calculator CreateCalculator()
        {
            var calculator = serviceProvider.GetService<Calculator>();

            return calculator;
        }

        public IServiceProvider Configure()
        {
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);

             return serviceCollection.BuildServiceProvider();

        }

        private static void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging(configure => configure.AddConsole())
              .Configure<LoggerFilterOptions>(options => options.MinLevel = LogLevel.Information)
              .AddScoped<Calculator>();

            services.AddScoped<ITokenizer, Tokenizer>();
        }
    }
}
