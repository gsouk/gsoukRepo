﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// The Node which represents a Binary Operation
    /// </summary>
    public class OperationNode:Node
    {
        public OperatorToken Operator { get; set; }


        public override double Evaluate()
        {
            try
            {
                var left = LeftNode.Evaluate();
                var right = RightNode.Evaluate();

                return
                    Operator.BinaryOperation(left, right);
            }
            catch
            {
                throw new MissingValueException("could not evaluate node,possibly missing an apply statement");

            }
        }

    }
}
