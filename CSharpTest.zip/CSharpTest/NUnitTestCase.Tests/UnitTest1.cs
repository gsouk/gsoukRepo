using ClassLibraryCSharpTest;
using NUnit.Framework;

namespace NUnitTestCase.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
            //NUnitTestDemo m = new NUnitTestDemo();
        }

        [Test]
        public void TestAdd()
        {

            NUnitTestDemo m = new NUnitTestDemo();
            Assert.AreEqual(m.Add(2, 4),6);
        }
    }
}