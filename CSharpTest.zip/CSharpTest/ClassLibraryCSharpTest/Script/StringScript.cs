﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// A simple implementation of a script that takes a comma seperated string and
    /// splits it into a IEnumerable so it can be used in a foreach statement
    /// </summary>
    public class StringScript:IScript
    {
        private string script;


        public StringScript(string script)
        {
            this.script = script;
        }

        public IEnumerable<string> GetLines()
        {
            return script.Split(',');
        }
    }
}
