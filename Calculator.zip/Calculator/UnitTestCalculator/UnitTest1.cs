﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestCalculator
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod01_Pass()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("add 5,multiply 3,apply 3"), 24);
        }
        [TestMethod]
        public void TestMethod02_Fail()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("1"), 1);
        }
        [TestMethod]
        public void TestMethod03_Fail()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("a"), 1);
        }
        [TestMethod]
        public void TestMethod04_Fail()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt(""), 1);
        }
        [TestMethod]
        public void TestMethod05_Fail()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("add 5,"), 1);
        }
        [TestMethod]
        public void TestMethod06_Pass()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("add 2, multiply 2, apply 3"), 10);
        }
        [TestMethod]
        public void TestMethod07_Pass()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("add 4, multiply 5, apply 6"), 50);
        }
        [TestMethod]
        public void TestMethod08_Fail()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("adt 7, multiply 8, apply 9"), 1);
        }
        [TestMethod]
        public void TestMethod09_Pass()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("divide 10, subtract 3, apply 2"), 2);
        }
        [TestMethod]
        public void TestMethod10_Fail()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("add 10, muldiply 11, apply 12"), 1);
        }
        [TestMethod]
        public void TestMethod11_Pass()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("add 2, multiply 2, divide 2, subtract 2, apply 3"), 3);
        }
        [TestMethod]
        public void TestMethod12_Fail()
        {
            Assert.AreEqual(Calculator.frmCalculator.CalculateIt("add 13, multiply 14, appli 15"), 1);
        }
    }
}
