﻿using ClassLibraryCSharpTest.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Implementation of the tokenizer which converts instruction strings into nodes
    /// </summary>
    public class Tokenizer:ITokenizer
    {

        public string ReduceWhitespace(string s)
        {
            Regex trimmer = new Regex(@"\s\s+");

            return trimmer.Replace(s, " ");
        }

        public OperationNode Parse(string line)
        {
           
            
            string[] elements = line.Split(' ');

            if(elements.Length<2)
            {
                throw new Exception("not enough arguments in instruction");
            }
            OperationNode node = new OperationNode();

            node.Operator = new OperatorToken(elements[0]);

            node.RightNode = new NodeConstant(elements[1]);


                return node;
        }
    }
}
