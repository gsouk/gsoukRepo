﻿namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Unused concept as space is treated simply as a seperator not a processed token
    /// </summary>
    public class SpaceToken : IToken
    {

    }

}