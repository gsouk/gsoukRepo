﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// This is used to hold the right hand side value of the instruction which will 
    /// be used to hold the constant values used in the binary operations
    /// 
    /// </summary>
    public class NodeConstant : Node
    {
        private double value;


       public NodeConstant(string value)
        {
            this.value = double.Parse(value);
        }

        public NodeConstant(double value)
        {
            this.value = value;
        }

        public override double Evaluate()
        {
            return value;
        }
        public double Value
        {
            get
            {
                return value;
            }
        }
    }
}
