﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Throw Exception if a node does NOT have values to evaluate
    /// </summary>
    public class MissingValueException:Exception
    {
        public MissingValueException()
        {

        }

        public MissingValueException(string message)
            : base(message)
        {

        }

        public MissingValueException(string message, Exception inner)
            : base(message, inner)
        {

        }
    }
}
