﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Within this class we use the string script as it works
    /// well without unit tests but we could create a FileScript
    /// based on the interface below which would read scripts from files
    /// </summary>
    public interface IScript
    {
         IEnumerable<string> GetLines();
    }
}
