﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Throw Exception if the instruction does not match the format of regex
    /// </summary>
    public class SyntaxException: Exception
    {
        public SyntaxException()
        {

        }

        public SyntaxException(string message) 
            : base(message)
        {

        }

        public SyntaxException(string message,Exception inner) 
            : base(message,inner)
        {

        }
    }
}
