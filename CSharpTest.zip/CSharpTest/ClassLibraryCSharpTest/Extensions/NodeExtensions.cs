﻿using ClassLibraryCSharpTest.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Node exention to quickly check whether the node
    /// contains the Apply command so we can handle it
    /// </summary>
    public static class NodeExtensions
    {

        public static bool IsApplyOperation(this Node node)
        {
            using (var applynode = node as OperationNode)
            {
                if (applynode != null && applynode.Operator.Operator == Operators.apply)
                {
                    return true;
                }

                return false;
            }
         }
    }
}
