using NUnit.Framework;
using ClassLibraryCSharpTest;
using ClassLibraryCSharpTest.Common;

namespace NUnitTestCase
{
    public class Tests
    {
        Calculator calculator;
        
        [SetUp]
        public void Setup()
        {
            CalculatorBox CalculatorBox = new CalculatorBox();

            calculator = CalculatorBox.CreateCalculator();
        }

        [Test]
        public void TestAddition()
        {
            NUnitTestDemo a = new NUnitTestDemo();
            Assert.AreEqual(a.Add(2, 4), 6);
        }

        [Test]
        public void TestSubtraction()
        {
            NUnitTestDemo b = new NUnitTestDemo();
            Assert.AreEqual(b.Sub(10, 5), 5);
        }

        [TestCase("add 2,multiply 3,apply 3", ExpectedResult = 15)]
        [TestCase("multiply 9,apply 5", ExpectedResult = 45)]
        public double assignment_cases_calculator_tests(string script)
        {
            StringScript Script = new StringScript(script);
            return calculator.Process(Script);
        }

    }
}