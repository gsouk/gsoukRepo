﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Throw Exceptionh if the operator in the instruction string is unknown
    /// </summary>
    public class UnknownOperatorException:Exception
    {

        public UnknownOperatorException()
        {

        }

        public UnknownOperatorException(string message)
            : base(message)
        {

        }

        public UnknownOperatorException(string message, Exception inner)
            : base(message, inner)
        {

        }
    }
}
