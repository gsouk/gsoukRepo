﻿using ClassLibraryCSharpTest;
using ClassLibraryCSharpTest.Common;
using System;


namespace ConsoleAppTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // Let's check the NUnit test Demo class if it's working
            //NUnitTestDemo m = new NUnitTestDemo();

            //Console.WriteLine("(2 + 4) = {0}", m.Add(2, 4));
            //Console.WriteLine("(10 - 5) = {0}", m.Sub(10, 5));
            //Console.ReadLine();

            // Now set up the line of instructions comprising of a keyword and a number separated 
            // by comma and finally the word "apply" followed by the number

            // Example 01
            //string script = "add 2,multiply 3,apply 3";

            // Example 02
            //string lineOfinput = "add 5,multiply 3,apply 3";
            string lineOfinput = "add 5,";

            StringScript Script = new StringScript(lineOfinput);

            CalculatorBox CalculatorBox = new CalculatorBox();

            Calculator calculator;

            calculator = CalculatorBox.CreateCalculator();

            Console.Write("add 5,multiply 3,apply 3 = ");
            Console.WriteLine(calculator.Process(Script));

            Console.ReadLine();
        }
    }
}
