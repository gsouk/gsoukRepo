﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryCSharpTest.Common
{
    /// <summary>
    /// Interface which defines the tokenizer functionally
    /// also registered in the DI container
    /// </summary>
    public interface ITokenizer
    {
         OperationNode Parse(string line);
         string ReduceWhitespace(string s);

    }
}
